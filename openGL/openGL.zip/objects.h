
#ifndef POINT_H
#define POINT_H

#include <GL/freeglut.h>
#include <GL/gl.h>

// color struct
typedef struct rgb {
    float r;
    float g;
    float b;
} rgb;

class Point {
public:
    float x, y;
    rgb color; 
    Point(float, float, rgb);

    bool collision(float, float, int);

    void render();
};

class Line {
public:
    float x1, y1, x2, y2;
    rgb color; 
    Line(float, float, float, float, rgb);

    bool collision(float, float, int);

    void render();
};

class Polygon {
public:
    float *x, *y;
    int n;
    rgb color; 
    Polygon(float*, float*, int, rgb);

    bool collision(float, float, int);

    void render();
};

class Triangle {
public:
    float x1, y1, x2, y2, x3, y3;
    rgb color; 
    Triangle(float, float, float, float, float, float, rgb);

    bool collision(float, float, int);

    void render();
};

// struct with objects
typedef struct objects {
    Point* points;
    Line* lines;
} objects;



#endif