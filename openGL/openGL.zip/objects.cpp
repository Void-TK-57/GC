
#include "objects.h"


#include <GL/freeglut.h>
#include <GL/gl.h>

// ==========================================================================================================================
// Point Class
// ==========================================================================================================================


Point::Point(float x_value, float y_value, rgb color_value ) : x(x_value), y(y_value), color(color_value) {}

// function to check collision with a click x, y with a toleranceerance
bool Point::collision(float p_x, float p_y, int tolerance = 5) {
    return (x < p_x + tolerance) && (x > p_x - tolerance) && (y < p_y + tolerance) && (y > p_y - tolerance);
}

// function to render the point
void Point::render() {
    // begin points
    glBegin(GL_POINTS);
        glColor3f(color.r, color.g, color.b);
        glVertex2f(x, y);
    glEnd();
}

// ==========================================================================================================================
// Line Class
// ==========================================================================================================================


Line::Line(float x1_value, float y1_value, float x2_value, float y2_value, rgb color_value ) : x1(x1_value), y1(y1_value), x2(x2_value), y2(y2_value), color(color_value) {}

/* function to check collision with a click x, y with a toleranceerance
bool Line::collision(float p_x, float p_y, int tolerance = 5) {
    return (x < p_x + tolerance) && (x > p_x - tolerance) && (y < p_y + tolerance) && (y > p_y - tolerance);
}
*/

// function to render the point
void Line::render() {
    // begin points
    glBegin(GL_LINES);
        glColor3f(color.r, color.g, color.b);
        glVertex2f(x1, y1);
        glVertex2f(x2, y2);
    glEnd();
}

// ==========================================================================================================================
// Polygon Class
// ==========================================================================================================================


Polygon::Polygon(float* x_values, float* y_values, int size, rgb color_value ) : x(x_values), y(y_values), n(size), color(color_value) {}

/* function to check collision with a click x, y with a toleranceerance
bool Line::collision(float p_x, float p_y, int tolerance = 5) {
    return (x < p_x + tolerance) && (x > p_x - tolerance) && (y < p_y + tolerance) && (y > p_y - tolerance);
}
*/

// function to render the point
void Polygon::render() {
    // begin points
    glBegin(GL_POLYGON);
        glColor3f(color.r, color.g, color.b);
        // for each point
        for (int i = 0; i < n; i++) {
            glVertex2f(x[i], y[i]);
        }
        
    glEnd();
}

// ==========================================================================================================================
// Triangle Class
// ==========================================================================================================================


Triangle::Triangle(float x1_value, float y1_value, float x2_value, float y2_value, float x3_value, float y3_value, rgb color_value ) : x1(x1_value), y1(y1_value), x2(x2_value), y2(y2_value), x3(x3_value), y3(y3_value), color(color_value) {}

/* function to check collision with a click x, y with a toleranceerance
bool Line::collision(float p_x, float p_y, int tolerance = 5) {
    return (x < p_x + tolerance) && (x > p_x - tolerance) && (y < p_y + tolerance) && (y > p_y - tolerance);
}
*/

// function to render the point
void Triangle::render() {
    // begin points
    glBegin(GL_TRIANGLES);
        glColor3f(color.r, color.g, color.b);
        glVertex2f(x1, y1);
        glVertex2f(x2, y2);
        glVertex2f(x3, y3);
    glEnd();
}

