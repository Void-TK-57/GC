#include <GL/freeglut.h>
#include <GL/gl.h>

#include "objects.h"

void renderFunction()
{   float width = 250, height = 250;
    glClearColor(0.0, 0.0, 0.0, 0.0);
    glClear(GL_COLOR_BUFFER_BIT);

    Line* line = new Line(0.5, 0.2, -0.5, 0.2, rgb {0.0, 1.0, 0.0} );
    line->render();
    
    float x[4] = {-0.2, 0.0, 0.2, 0.0};
    float y[4] = {0.0, 0.2, 0.0, -0.2};
    Polygon* polygon = new Polygon(x, y, 4, rgb {0.0, 0.0, 1.0});
    polygon->render();

    Triangle* triangle = new Triangle(0.0, -0.2, -0.1, -0.3, 0.1, -0.3, rgb {1.0, 1.0, 0.0} );
    triangle->render();

    Point* point = new Point(0.0, 0.0, rgb {1.0, 1.0, 1.0} );
    point->render();

      
    glFlush();
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE);
    glutInitWindowSize(500,500);
    glutInitWindowPosition(100,100);
    glutCreateWindow("GC");
    glutDisplayFunc(renderFunction);
    glutMainLoop();    
    return 0;
}